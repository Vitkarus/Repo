var totalSeconds
var totalDecimalSeconds
var currentProgress
var currentDecimalSeconds
var currentDecimalMinutes
var currentDecimalHours

function updateData() 
{ 
  var currentTime = new Date();
  var currentYear = currentTime.getYear() + 1900;
  var currentMonth = currentTime.getMonth() + 1;
  var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
  var currentHours = currentTime.getHours();
  var currentMinutes = currentTime.getMinutes();
  var currentSeconds = currentTime.getSeconds();

  totalSeconds = currentHours*60*60 + currentMinutes*60 + currentSeconds;
  currentProgress = Math.trunc(totalSeconds/86400*100);

  totalDecimalSeconds = totalSeconds/0.864;

  currentDecimalHours = Math.trunc(totalDecimalSeconds/10000);
  currentDecimalMinutes = Math.trunc((totalDecimalSeconds - currentDecimalHours*10000)/100);
  currentDecimalSeconds = Math.trunc(totalDecimalSeconds - currentDecimalHours*10000 - currentDecimalMinutes*100);

  updateVisuals();
  // document.getElementById("month").innerHTML = currentMonth;
  // document.getElementById("year").innerHTML = currentYear;
}
function updateVisuals()
{
  document.getElementById("digits").innerHTML = currentDecimalHours + '.' + currentDecimalMinutes + '.' + currentDecimalSeconds;
  document.getElementById("time-bar-percent").innerHTML = currentProgress + ' %';
  document.getElementById("time-bar-color-limiter").style.width = currentProgress + '%';
}

function init()
{
  updateData()
  setInterval("updateData()", 1000);
}
